<!DOCTYPE html>
<html>
	<head>
		<title>Portal - Rulko.ca</title>
		<meta http-equiv="Content-Type" content="text/html" />
		<meta charset="UTF-8" />
		<meta name="author" content="Theo Rulko" />
		<link rel='icon' href='../assets/img/icon.png' type='image/png' />
        <link rel='stylesheet' href='../assets/flickity.css' />
        <link rel='stylesheet' href='../assets/style.css' />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<noscript>
            <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,900" rel="stylesheet" />
            <link rel="stylesheet" href="../assets/icons/css/all.min.css" />
        </noscript>
	</head>
	<body id="body" class="is-loading">
        <div class="hamburger"><div class="hamburger-box"><div class="hamburger-inner"></div></div></div>
        <div class="menu" id="top">
            <div class="menu-item" data-target="home"><a href="../#one">Home</a></div><br/>
            <div class="menu-item" data-target="portfolio" style="transition: transform 0.25s ease 0.05s, opacity 0.25s ease 0.05s, all 0.25s ease"><a href="../#two">Portfolio</a></div><br/>
            <div class="menu-item" data-target="contact" style="transition: transform 0.25s ease 0.1s, opacity 0.25s ease 0.05s, all 0.25s ease">Contact</div><br/>
            <div class="menu-item" style="transition: transform 0.25s ease 0.15s, opacity 0.25s ease 0.05s, all 0.25s ease"><a href="#">Portal</a></div>
            <div class="togglebox"  title="Toggle Light/Dark Modes">
                <label class="switch" for="checkbox">
                    <input type="checkbox" id="checkbox" />
                    <div class="slider round"></div>
                </label>
            </div>
        </div>
        <div class="contact">
            <div class="content">
                <h1>Contact</h1><div id="contact-bin"></div>
                <h3><b>Hello!</b> I'm an undergraduate engineering student at the University of Michigan, Ann Arbor, who likes to dabble in web design and branding. You can contact me with the form below!</h3>
                <form action="https://formspree.io/theo@rulko.ca" method="POST">
                    <div class="input-wrap half">
                        <label for="name"><i class="fas fa-user-alt"></i></label>
                        <input type="text" name="name" placeholder="Name" />
                        <div style="clear:both"></div>
                    </div>
                    <div class="input-wrap half">
                        <label for="name"><i class="fas fa-envelope"></i></label>
                        <input type="email" name="_replyto" placeholder="Email"/>
                        <div style="clear:both"></div>
                    </div>
                    <textarea name="message" placeholder="Message"></textarea>
                    <button type="submit" class="button">Send</button>
                    
                    <!-- Hidden Inputs -->
                        <input type="hidden" name="_next" value="https://rulko.ca/Portal/login.php?s=y" />
                        <input type="hidden" name="_subject" value="Message from Rulko.ca" />
                        <input type="text" name="_gotcha" style="display:none" />
                    <!-- End -->
                </form>
            </div>
            <div class="contact-button"><i class="far fa-user-circle"></i></div>
        </div>
        <div class="wrapper">
            <div class="content">
                <h1>Portal</h1>
                <h3 style="color: #bbbbbb">Unauthorized access is prohibited.<br/><small class="login-error"></small><small class="login-success"></small></h3>
                <form id="login" method="post" style="max-width: 500px">
                    <div class="input-wrap">
                        <label for="name"><i class="fas fa-user-alt"></i></label>
                        <input type="text" placeholder="Username" autocomplete="off" id="username" name="username" class="user" required/>
                        <div style="clear:both"></div>
                    </div>
                    <div class="input-wrap">
                        <label for="name"><i class="fas fa-lock"></i></label>
                        <input type="password" placeholder="Password" autocomplete="off" id="password" name="password" required/>
                        <div style="clear:both"></div>
                    </div>
                    <button type="submit" class="button showcase-button-special">Log In</button>
                </form>
            </div>           
        </div>
		<!-- External Scripts -->
			<script src="../assets/jquery.min.js" type="5c1064a0d27a5a9aeb249ac9-text/javascript"></script>
            <script src="../assets/flickity.pkgd.min.js" type="5c1064a0d27a5a9aeb249ac9-text/javascript"></script>
            <script src="../assets/flickity-fullscreen.js" type="5c1064a0d27a5a9aeb249ac9-text/javascript"></script>
            <script src="../assets/portfolio.js" type="5c1064a0d27a5a9aeb249ac9-text/javascript"></script>
            <script type="5c1064a0d27a5a9aeb249ac9-text/javascript">
                var gfonts = document.createElement('link');
                gfonts.rel = 'stylesheet';
                gfonts.href = 'https://fonts.googleapis.com/css?family=Montserrat:400,700,900';
                gfonts.type = 'text/css';
                var godefer = document.getElementsByTagName('link')[0];
                godefer.parentNode.insertBefore(gfonts, godefer);

                var iconfonts = document.createElement('link');
                iconfonts.rel = 'stylesheet';
                iconfonts.href = '../assets/icons/css/all.min.css';
                iconfonts.type = 'text/css';
                var godefer2 = document.getElementsByTagName('link')[0];
                godefer2.parentNode.insertBefore(iconfonts, godefer2);
            </script>
		<!-- End External Scripts -->
    <script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="5c1064a0d27a5a9aeb249ac9-|49" defer></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"c9b54720b3a24e1792f216c875a11b2e","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>